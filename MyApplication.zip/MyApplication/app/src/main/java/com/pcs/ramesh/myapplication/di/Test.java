package com.pcs.ramesh.myapplication.di;

import android.content.Context;

import com.pcs.ramesh.myapplication.presenter.LoginPresenter;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

/**
 * Created by pcs-03 on 5/3/15.
 */
@Singleton
public class Test {

    final LoginPresenter name;

    @Inject
    Test(Context context, @Named("my") LoginPresenter name) {
        this.name = name;
    }
}
