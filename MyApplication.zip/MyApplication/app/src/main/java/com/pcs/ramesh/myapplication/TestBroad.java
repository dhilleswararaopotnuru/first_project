package com.pcs.ramesh.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by pcs-03 on 5/3/15.
 */
public class TestBroad extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {

    }


}
