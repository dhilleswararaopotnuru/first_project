package com.pcs.ramesh.myapplication.view;

/**
 * Created by pcs-03 on 4/3/15.
 */
public interface LoginView {

    void showLoading();

    void showValidationError();

    void onSuccess();

    void onFail();

    void hideLoading();
}
