package com.pcs.ramesh.myapplication.di.module;

import com.pcs.ramesh.myapplication.format.Formatter;
import com.pcs.ramesh.myapplication.format.MyDateFormatter;
import com.pcs.ramesh.myapplication.format.ReleaseDateFormatter;
import com.pcs.ramesh.myapplication.presenter.LoginPresenter;
import com.pcs.ramesh.myapplication.presenter.LoginPresenterImpl;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * @author Ramesh
 */
@Module(
        complete = false,
        library = true
)
public class PresenterModule {

    @Provides
    @Named("release")
    @Singleton
    LoginPresenter providesPresenter(@Named("release") Formatter f) {
        return new LoginPresenterImpl(f);
    }

    @Provides
    @Named("my")
    @Singleton
    LoginPresenter providesPresenter1(@Named("my") Formatter f) {
        return new LoginPresenterImpl(f);
    }

    @Provides
    @Named("release")
    @Singleton
    Formatter providesPresenter() {
        return new ReleaseDateFormatter();
    }

    @Provides
    @Named("my")
    @Singleton
    Formatter providesPresenter1() {
        return new MyDateFormatter();
    }


}
