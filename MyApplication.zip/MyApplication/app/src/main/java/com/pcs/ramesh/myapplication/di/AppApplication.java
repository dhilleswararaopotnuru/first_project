package com.pcs.ramesh.myapplication.di;

import android.app.Application;


import com.pcs.ramesh.myapplication.di.module.RootModule;

import dagger.ObjectGraph;

/**
 * @author Ramesh
 */
public class AppApplication extends Application {

    private ObjectGraph objectGraph;

    @Override
    public void onCreate() {
        super.onCreate();
        injectDependencies();
    }

    private void injectDependencies() {
        objectGraph = ObjectGraph.create(new RootModule(this));
        objectGraph.inject(this);
    }

    public void inject(Object object) {
        objectGraph.inject(object);
    }
}
