package com.pcs.ramesh.myapplication;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.pcs.ramesh.myapplication.di.AppApplication;
import com.pcs.ramesh.myapplication.di.Test;
import com.pcs.ramesh.myapplication.view.LoginView;
import com.pcs.ramesh.myapplication.presenter.LoginPresenter;
import com.pcs.ramesh.myapplication.presenter.LoginPresenterImpl;

import javax.inject.Inject;
import javax.inject.Named;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;


public class MainActivity extends ActionBarActivity implements LoginView {

    @Inject
    @Named("release")
    LoginPresenter p;
    @Inject
    Test test;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((AppApplication) getApplicationContext()).inject(this);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
        p.setView(this);
        p.initialize();

    }

    @OnClick(R.id.btnOk)
    public void onBtnClick() {
        p.validation("Ramesh", "Ramesh");
        sendBroadcast(new Intent("com.ramesh.action"));
    }

    @Override
    public void showLoading() {
        Toast.makeText(this, "Please wait...", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showValidationError() {
        Toast.makeText(this, "User name and password error", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onSuccess() {
        Toast.makeText(this, "Success!!!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFail() {

    }

    @Override
    public void hideLoading() {

    }
}
