package com.pcs.ramesh.myapplication.di.module;

import android.content.Context;

import com.pcs.ramesh.myapplication.MainActivity;
import com.pcs.ramesh.myapplication.TestBroad;
import com.pcs.ramesh.myapplication.di.AppApplication;
import com.squareup.otto.Bus;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * @author Ramesh
 */

@Module(
        includes = {
                PresenterModule.class,
        },
        injects = {
                AppApplication.class,
                MainActivity.class,
                TestBroad.class
        },
        library = true
)
public class RootModule {

    private final Context context;

    public RootModule(Context context) {
        this.context = context;
    }

    @Provides
    @Singleton
    public Context provideApplicationContext() {
        return context;
    }

    @Provides
    @Singleton
    public Bus provideBusEvent() {
        return new Bus();
    }
}
