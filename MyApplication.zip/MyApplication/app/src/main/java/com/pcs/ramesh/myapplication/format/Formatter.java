package com.pcs.ramesh.myapplication.format;

/**
 * @author Ramesh
 */
public interface Formatter<TFrom> {

    String format(TFrom from);
}
