package com.pcs.ramesh.myapplication.presenter;

import com.pcs.ramesh.myapplication.view.LoginView;

/**
 * Created by pcs-03 on 4/3/15.
 */
public interface LoginPresenter<T extends LoginView> {


    void setView(T view);

    void initialize();

    void validation(String username, String password);
}
