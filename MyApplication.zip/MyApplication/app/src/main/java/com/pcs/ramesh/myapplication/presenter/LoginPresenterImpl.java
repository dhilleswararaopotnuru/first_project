package com.pcs.ramesh.myapplication.presenter;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.pcs.ramesh.myapplication.format.Formatter;
import com.pcs.ramesh.myapplication.view.LoginView;

import java.util.Date;

/**
 * Created by pcs-03 on 4/3/15.
 */
public class LoginPresenterImpl implements LoginPresenter {

    private LoginView loginView;
    private Formatter formatter;

    public LoginPresenterImpl(Formatter formatter) {
        this.formatter = formatter;
    }


    @Override
    public void setView(LoginView view) {
        loginView = view;
    }

    @Override
    public void initialize() {

    }

    @Override
    public void validation(final String username, final String password) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.i("Time Stamp", formatter.format(new Date()));
                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                    loginView.showValidationError();
                } else {
                    loginView.onSuccess();
                }
            }
        }, 2000);

    }
}
